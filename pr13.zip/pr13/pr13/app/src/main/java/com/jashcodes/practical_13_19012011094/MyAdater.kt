package com.jashcodes.practical_13_19012011094

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class MyAdater(var mCtx:Context, var resources:Int, var items:List<Message>):ArrayAdapter<Message>(mCtx,resources,items){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val layoutInflater:LayoutInflater = LayoutInflater.from(mCtx)
        val view:View=  layoutInflater.inflate(resources,null)
         val textview1:TextView=view.findViewById(R.id.textView)
          val textview2:TextView=view.findViewById(R.id.textView5)

        var ob : Message = items[position]

        textview1.text="From: "+ob.message_from
        textview2.text=ob.body_message

        return view
    }


}