package com.jashcodes.practical_13_19012011094

 class Message(var message_from: String, var body_message: String) {


 }