package com.jashcodes.practical_13_19012011094

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsManager
import android.widget.*
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    val list = mutableListOf<Message>()
val context:Context=this//very imp





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        list.add(Message("Hello","Jash"))
//        list.add(Message("Hello","Jash"))
//        list.add(Message("Hello","Jash"))
            val listView = findViewById<ListView>(R.id.listView)





        listView.adapter = MyAdater(this,R.layout.adapter_view_layout,list)


        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)
{
ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.RECEIVE_SMS,android.Manifest.permission.SEND_SMS),
    111)

    //if permission not granted then ask for permission
    //if granted check result of permission if result is allowed then go to recieve msg


    //and in else part if permission is already granted then no problem then go to recieve msg


}
        else
{
     recievemsg()
}



        val button:Button = findViewById(R.id.button)
        val message_to_send:EditText = findViewById(R.id.editTextTextMultiLine)
        val whom_to_send:EditText = findViewById(R.id.editTextTextPersonName2)

        button.setOnClickListener{

            if(message_to_send.text.isEmpty() or whom_to_send.text.isEmpty())
            {
                Toast.makeText(applicationContext,"Please enter values",Toast.LENGTH_SHORT).show()

            }
            else
            {
                var sms = SmsManager.getDefault()
                sms.sendTextMessage(whom_to_send.text.toString(),"Jash",message_to_send.text.toString(),null,null)


                Toast.makeText(applicationContext,"Message send successfully to "+whom_to_send.text.toString(),Toast.LENGTH_LONG).show()

                message_to_send.setText("")
                whom_to_send.setText("")

            }



        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if(requestCode==111 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            recievemsg()
    }

    private fun recievemsg() {

   var br = object:BroadcastReceiver(){
       override fun onReceive(p0: Context?, p1: Intent?) {
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
            {
                    for(sms in Telephony.Sms.Intents.getMessagesFromIntent(p1)){
                        val listView = findViewById<ListView>(R.id.listView)





//                        Toast.makeText(applicationContext,sms.displayMessageBody,Toast.LENGTH_LONG).show()
//                        messages.add(sms.displayOriginatingAddress)
//                        messages.add(sms.displayMessageBody)

//                        val ob = Message(sms.originatingAddress.toString(),sms.displayMessageBody.toString())

                        val a = sms.displayOriginatingAddress
                        val b = sms.displayMessageBody
                        list.add(Message(a,b))

                        listView.adapter = MyAdater(context,R.layout.adapter_view_layout,list)

                        Toast.makeText(applicationContext,list.size.toString(),Toast.LENGTH_SHORT).show()







                    }
            }
       }


   }
        registerReceiver(br, IntentFilter("android.provider.Telephony.SMS_RECEIVED"))

    }
}