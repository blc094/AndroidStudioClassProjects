package com.example.p10_bhanwar_19012011094

class Login {
    companion object{

        var fullname=""
        var phone=""
        var email=""
        var city=""
        var password=""
        var confirm_pass=""

    }
}
