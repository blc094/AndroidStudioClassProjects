package com.example.a19012011094_p12

class Model {
    lateinit var id: String
    lateinit var fname: String
    lateinit var lname: String
    lateinit var phone: String
    lateinit var address: String

    constructor(id: String,fname: String,lname: String,phone: String,address: String) {
        this.id = id
        this.fname = fname
        this.lname = lname
        this.phone = phone
        this.address = address
    }

    constructor()
}