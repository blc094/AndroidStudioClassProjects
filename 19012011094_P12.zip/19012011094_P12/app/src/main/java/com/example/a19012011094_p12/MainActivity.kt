package com.example.a19012011094_p12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ListView
import android.widget.ProgressBar
import com.example.a19012011094_p12.CustomAdapter
import com.example.a19012011094_p12.Model
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    lateinit var listView_details: ListView
    var arrayList_details:ArrayList<Model> = ArrayList();
    val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView_details = findViewById<ListView>(R.id.listView) as ListView
        run("https://run.mocky.io/v3/5e5c2658-8f2e-4df9-aed1-d077bee01225")
    }

    fun run(url:String) {
        val request = Request.Builder().url(url).build()
        client.newCall(request).enqueue(object : Callback{
            override fun onFailure(call: Call, e: IOException) {
            }

            override fun onResponse(call: Call, response: Response) {
                var str_response = response.body()!!.string()
                val json_contact:JSONObject = JSONObject(str_response)
                var jsonarray_info:JSONArray = json_contact.getJSONArray("info")
                val i:Int = 0
                var size:Int = jsonarray_info.length()
                arrayList_details = ArrayList();
                for (i in 0..size-1) {
                    var json_objectdetails: JSONObject = jsonarray_info.getJSONObject(i)
                    var model:Model = Model();
                    model.id = json_objectdetails.getString("id")
                    model.fname = json_objectdetails.getString("fname")
                    model.lname = json_objectdetails.getString("lname")
                    model.phone = json_objectdetails.getString("phone")
                    model.address = json_objectdetails.getString("address")
                    arrayList_details.add(model)
                }

                runOnUiThread {
                    val obj_adapter : CustomAdapter
                    obj_adapter = CustomAdapter(applicationContext,arrayList_details)
                    listView_details.adapter = obj_adapter
                }
            }
        })
    }
}